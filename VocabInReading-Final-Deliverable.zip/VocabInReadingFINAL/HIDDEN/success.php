<?php $active = 5 ; require 'header.php'; ?>

 <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Backup/Import Database <small> Import Data</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li class="active">
                                <i class="fa fa-gear"></i> Database updated successfully.</li>
                        </ol>
                    </div>
                </div>
<?php require 'footer.php';?>