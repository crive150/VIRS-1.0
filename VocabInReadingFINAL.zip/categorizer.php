<?php require_once('Connections/sql.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_sql, $sql);
$query_awl = "SELECT word FROM awl ORDER BY word ASC";
$awl = mysql_query($query_awl, $sql) or die(mysql_error());
$row_awl = mysql_fetch_assoc($awl);
$totalRows_awl = mysql_num_rows($awl);

mysql_select_db($database_sql, $sql);
$query_lo = "SELECT word FROM lo ORDER BY word ASC";
$lo = mysql_query($query_lo, $sql) or die(mysql_error());
$row_lo = mysql_fetch_assoc($lo);
$totalRows_lo = mysql_num_rows($lo);

mysql_select_db($database_sql, $sql);
$query_med = "SELECT word FROM med ORDER BY word ASC";
$med = mysql_query($query_med, $sql) or die(mysql_error());
$row_med = mysql_fetch_assoc($med);
$totalRows_med = mysql_num_rows($med);

mysql_select_db($database_sql, $sql);
$query_hi = "SELECT word FROM hi ORDER BY word ASC";
$hi = mysql_query($query_hi, $sql) or die(mysql_error());
$row_hi = mysql_fetch_assoc($hi);
$totalRows_hi = mysql_num_rows($hi);

 $active = 0;   require 'header.php';   ?>
  
  
  <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           Enhanced Text 
                        </h1>
                        
                    </div>
                </div>
                <!-- /.row -->

                
<p>Output:</p>


<p><?php

	function helper($needle, $haystack){
	foreach ( $haystack as $i ){
		//echo "Looking for $needle...";
	if( $i == $needle) { return 1; }
	} return 0; } 
	
	//get input
	ob_start();
	echo $_POST['input'];
	$out = ob_get_contents();
	ob_end_clean();
	
	//$out_arr = array();
	$out_arr = preg_split('/[\s.,;:–]+/', $out);
	//print_r($out_arr);
	
	
	//get arrays
	
	do {  $awl_array[] = $row_awl['word']; 
   } while ($row_awl = mysql_fetch_assoc($awl)); 
   
   do {  $lo_array[] = $row_lo['word']; 
   } while ($row_lo = mysql_fetch_assoc($lo)); 
	
	do {  $med_array[] = $row_med['word']; 
   } while ($row_med = mysql_fetch_assoc($med)); 
   
   do {  $hi_array[] = $row_hi['word']; 
   } while ($row_hi = mysql_fetch_assoc($hi)); 	
	
	 
	//$tok = strtok($out, " ");
	

/*    //using string tokenizer instead of arr (buggy)

while ($tok !== false)
{
	if(in_array($tok, $awl_array)){echo "<font color = \"green\"><a href=\"define.php?word=$tok\"$tok</font>";}
	else if(in_array($tok, $hi_array)){echo "<font color = \"blue\"><a href=\"define.php?word=$tok\"$tok</font>";}
	else if(in_array($tok, $med_array)){echo "<font color = \"pink\"><a href=\"define.php?word=$tok\"$tok</font>";}
	else if(in_array($tok, $lo_array)){echo "<font color = \"red\"><a href=\"define.php?word=$tok\"$tok</font>";}
	else{
	
echo "$tok ";}
$tok = strtok(" ");
}*/


//get dropdown values for custom color-coding (php complained when trying to use 
//POST array in echo so I gave them their own variables whatever)

$awlcolor = $_POST['awlc'];
$locolor = $_POST['loc'];
$medcolor = $_POST['medc'];
$hicolor = $_POST['hic'];

$aacc = 0;
$lacc = 0;
$macc = 0;
$hacc = 0; // accumulators for the four categories for new stats table

$total = 0; //overall acc

//print_r($med_array);
		
						//Output loop : POST check marks act as binary flags for each category
	foreach ($out_arr as $tok){
	if(helper($tok, $awl_array) && $_POST['AWL']){$aacc++;$total++;echo "<font color = \"$awlcolor\"><a onclick=\"window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,resizable=0'); return false;\" href=\"define.php?word=$tok\">$tok</a></font> ";}
	
	else if(helper($tok, $lo_array) && $_POST['lo']){$lacc++;$total++;echo "<font color = \"$locolor\"><a onclick=\"window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,resizable=0'); return false;\" href=\"define.php?word=$tok\">$tok</a></font> ";}
	
	else if(helper($tok, $med_array) && $_POST['med']){$macc++;$total++;echo "<font color = \"$medcolor\"><a onclick=\"window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,resizable=0'); return false;\" href=\"define.php?word=$tok\">$tok</a></font> ";}
	
	else if(helper($tok, $hi_array) && $_POST['hi']){$hacc++;$total++;echo "<font color = \"$hicolor\"><a onclick=\"window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,resizable=0'); return false;\" href=\"define.php?word=$tok\">$tok</a></font> ";}
	
	else{ echo "<a onclick=\"window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,resizable=0'); return false;\" href=\"define.php?word=$tok\">$tok</a> ";}

}
?>
	
</p>
<div class="row">
                    <div class="col-lg-12">
                        <div align="center" class="alert alert-info alert-dismissable">
					<table width="90%">
					<tr><td align="center" colspan=4>Enhanced Text Statistical Analysis</td></tr>
                    <tr>
                      <td><a onclick="window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,scrollbars=1,resizable=0');return false;" href="awl.php"><strong>AWL</strong></a> (Academic Word List)</td><td><a onclick="window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,scrollbars=1,resizable=0');return false;" href="lo.php"><strong>Low Frequency</strong></a> (Rare)</td><td><a onclick="window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,scrollbars=1,resizable=0');return false;" href="med.php"><strong>Medium Frequency</strong></a> (Uncommon)</td>
                    <td><a onclick="window.open(this.href, 'mywin', 'left=20,top=20,width=1000,height=800,toolbar=0,resizable=0,scrollbars=1');return false;" href="hi.php"><strong>High Frequency</strong></a> (Common)
                    </td></tr>
                    <tr><td><?php echo $aacc; ?> words</td><td><?php echo $lacc; ?> words</td><td><?php echo $macc; ?> words</td><td><?php echo $hacc; ?> words</td></tr>
                    <tr><td><?php echo round(($aacc / $total) * 100, 3); ?>% </td><td><?php echo round(($lacc / $total) * 100, 3); ?>% </td><td><?php echo round(($macc / $total) * 100, 3); ?>% </td>	
                    <td><?php echo round(($hacc / $total) * 100, 3); ?>% </td></tr>
                    </table>
                    </div>
                    </div>
                </div>

<p>Input:</p>
<form id="form1" name="form1" method="post" action="categorizer.php">
  <p>
    <label for="input"></label>
    <textarea name="input" style="height:400px; width:80%;" id="input"><?php echo $_POST['input']; ?></textarea>
  </p>
  <p>
  <input type="hidden" value = '0' name = "AWL" />
    <input name="AWL" type="checkbox" value='1' <?php if ($_POST['AWL']) { echo "checked";} //little bit of ingenuity ?>/>
    <label for="AWL">AWL</label>
    <select name="awlc" id="awlc">
      <option value="Green" <?php if ($awlcolor == "Green") echo "selected=\"selected\""; //little more ?>>Green</option> 
      <option value="Blue" <?php if ($awlcolor == "Blue") echo "selected=\"selected\"";?>>Blue</option>
      <option value="Pink" <?php if ($awlcolor == "Pink") echo "selected=\"selected\"";?>>Pink</option>
      <option value="Red" <?php if ($awlcolor == "Red") echo "selected=\"selected\"";?>>Red</option>
      <option value="Purple" <?php if ($awlcolor == "Purple") echo "selected=\"selected\"";?>>Purple</option>
      <option value="Cyan" <?php if ($awlcolor == "Cyan") echo "selected=\"selected\"";?>>Cyan</option>
      <option value="Lime" <?php if ($awlcolor == "Lime") echo "selected=\"selected\"";?>>Lime</option>
      <option value="Gold" <?php if ($awlcolor == "Gold") echo "selected=\"selected\"";?>>Gold</option>
    </select>
  </p>
  <p>
    <input type="hidden" value = '0' name = "lo" />
    <input name="lo" type="checkbox" value='1'  <?php if ($_POST['lo']) { echo "checked";} ?>/>
    <label for="lo">Low Frequency</label>
    <select name="loc" id="loc">
      <option value="Green" <?php if ($locolor == "Green") echo "selected=\"selected\"";?>>Green</option>
      <option value="Blue" <?php if ($locolor == "Blue") echo "selected=\"selected\"";?>>Blue</option>
      <option value="Pink" <?php if ($locolor == "Pink") echo "selected=\"selected\"";?>>Pink</option>
      <option value="Red" <?php if ($locolor == "Red") echo "selected=\"selected\"";?>>Red</option>
      <option value="Purple" <?php if ($locolor == "Purple") echo "selected=\"selected\"";?>>Purple</option>
      <option value="Cyan" <?php if ($locolor == "Cyan") echo "selected=\"selected\"";?>>Cyan</option>
      <option value="Lime" <?php if ($locolor == "Lime") echo "selected=\"selected\"";?>>Lime</option>
      <option value="Gold" <?php if ($locolor == "Gold") echo "selected=\"selected\"";?>>Gold</option>
    </select>
  </p>
  <p>
    <input type="hidden" value = '0' name = "med" />
    <input name="med" type="checkbox" value='1'  <?php if ($_POST['med']) { echo "checked";} ?>/>
    <label for="med">Medium  Frequency</label>
    <select name="medc" id="medc">
      <option value="Green" <?php if ($medcolor == "Green") echo "selected=\"selected\"";?>>Green</option>
      <option value="Blue" <?php if ($medcolor == "Blue") echo "selected=\"selected\"";?>>Blue</option>
      <option value="Pink" <?php if ($medcolor == "Pink") echo "selected=\"selected\"";?>>Pink</option>
      <option value="Red" <?php if ($medcolor == "Red") echo "selected=\"selected\"";?>>Red</option>
      <option value="Purple" <?php if ($medcolor == "Purple") echo "selected=\"selected\"";?>>Purple</option>
      <option value="Cyan" <?php if ($medcolor == "Cyan") echo "selected=\"selected\"";?>>Cyan</option>
      <option value="Lime" <?php if ($medcolor == "Lime") echo "selected=\"selected\"";?>>Lime</option>
      <option value="Gold" <?php if ($medcolor == "Gold") echo "selected=\"selected\"";?>>Gold</option>
    </select>
  </p>
  <p><style>a{color:inherit} </style>
  
  <input type="hidden" value = '0' name = "hi" />
    <input name="hi" type="checkbox" value='1'  <?php if ($_POST['hi']) { echo "checked";} ?>/>
    <label for="hi">High Frequency</label>
    <select name="hic" id="hic">
      <option value="Green" <?php if ($hicolor == "Green") echo "selected=\"selected\"";?>>Green</option>
      <option value="Blue" <?php if ($hicolor == "Blue") echo "selected=\"selected\"";?>>Blue</option>
      <option value="Pink" <?php if ($hicolor == "Pink") echo "selected=\"selected\"";?>>Pink</option>
      <option value="Red" <?php if ($hicolor == "Red") echo "selected=\"selected\"";?>>Red</option>
      <option value="Purple" <?php if ($hicolor == "Purple") echo "selected=\"selected\"";?>>Purple</option>
      <option value="Cyan" <?php if ($hicolor == "Cyan") echo "selected=\"selected\"";?>>Cyan</option>
      <option value="Lime" <?php if ($hicolor == "Lime") echo "selected=\"selected\"";?>>Lime</option>
      <option value="Gold" <?php if ($hicolor == "Gold") echo "selected=\"selected\"";?>>Gold</option>
    </select>
  </p>
  <p>
    <input type="submit" name="Submit" id="Submit" value="Categorize" />
  </p>
</form>



<p>&nbsp;</p>
</body>
</html>
<?php

mysql_free_result($awl);

mysql_free_result($lo);

mysql_free_result($med);

mysql_free_result($hi);
?>
